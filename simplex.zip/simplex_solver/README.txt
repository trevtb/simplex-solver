Eclipse:
---------------------------
Die Datei "eclipse_workspace.zip" einfach in den "workspace"-Ordner von Eclipse entpacken, um dort mit dem Projekt zu arbeiten. Natürlich kann der Sourcecode im dort enthaltenen "src"-Ordner auch einzeln betrachtet werden.

Ausführen:
---------------------------
Zum starten einfach das in diesem Ordner enthaltene simplex.jar aufrufen.
("java -jar simplex.jar")

Dokumentation:
---------------------------
Der Ordner "doc" enthält die Dokumentation des Sourcecodes. Zum betrachten einfach die dortige "index.html" aufrufen.
